# Dracula Wallpaper

> A collection of dark wallpapers for Dracula.

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/wallpaper](https://draculatheme.com/wallpaper).

## Team

These wallpapers were created by [kajwski](https://www.reddit.com/r/unixporn/comments/hbu7uu/oc_ive_made_a_custom_distroos_wallpaper_for/).

These wallpapers are maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/marp/graphs/contributors).

[![Brandon Reyes](https://avatars2.githubusercontent.com/u/69567027?v=v&s=70)](https://github.com/brandon-irs) |
--- |
[](https://github.com/brandon-irs) |

## License

[MIT License](./LICENSE)
